<?php
$host    = "localhost";
$user    = "root";
$pass    = "";
$db      = "biodata_reva";

$koneksi = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) { //cek koneksi
    die("Tidak bisa terkoneksi ke database");
}
$id              = "";
$namakelas       = "";
$Kompetensi      = "";
$tahun_pelajaran = "";
$keterangan      = "";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>biodata_reva</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        .mx-auto {
            width: 800px
        }

        .card {
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div class="mx-auto">
        <!-- untuk memasukkan data -->
        <div class="card">
            <div class="card-header">
                Create/Edit Data
            </div>
            <div class="card-body">
                <form action="" method="POST">
                    <div class="mb-3 row">
                        <label for="id" class="col-sm-2 col-form-label">id</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="id" value="<?php echo $id ?>">
                        </div>
                    </div>

                    <div class="mb-3 row">
                    <label for="namakelas" class="col-sm-2 col-form-label">namakelas</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="namakelas" value="<?php echo $namakelas ?>">
                    </div>
                </div>

                <div class="mb-3 row">
                <label for="kompetensi" class="col-sm-2 col-form-label">kompetensi</label>
                <div class="col-sm-10">
                    <select class="form-control" id="kompetensi">
                     <option value="">- Pilih Kompetensi -</option>
                     <option value="ANM" <?php if($Kompetensi == "ANM") echo "selected"?>" >ANM</option>
                     <option value="SIJA" <?php if($Kompetensi == "SIJA") echo "selected"?>" >SIJA</option>
                     <option value="TKJ" <?php if($Kompetensi == "TKJ") echo "selected"?>" >TKJ</option>
                     <option value="RPL"<?php if($Kompetensi == "RPL") echo "selected"?>" >RPL</option>
                     <option value="KPRC"<?php if($Kompetensi == "KPRC") echo "selected"?>" >KPRC</option>
                     <option value="TKR"<?php if($Kompetensi == "TKR") echo "selected"?>" >TKR</option>
                     <option value="TBSM" <?php if($Kompetensi == "TBSM") echo "selected"?> >TBSM</option>
                     <option value="DKV" <?php if($Kompetensi == "DKV") echo "selected"?> >DKV</option>
                     <option value="MM"<?php if($Kompetensi == "MM") echo "selected"?> >MM</option>
                    </select>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="tahun_pelajaran" class="col-sm-2 col-form-label">tahun_pelajaran</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="tahun_pelajaran" value="<?php echo $tahun_pelajaran ?>">
                </div>
            </div><div class="mb-3 row">
            <label for="keterangan" class="col-sm-2 col-form-label">keterangan</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="keterangan" value="<?php echo $keterangan ?>">
            </div>
        </div>
        <div class="col-12">
            <input type="submit" name="simpan" value="Simpan Data" class="btn-btn-primary"/>
        </div>
                </form>
            </div>
        </div>

        <!-- untuk mengeluarkan data -->
        <div class="card">
            <div class="card-header text-white bg-secondary">
                biodata_kelas
            </div>
            <div class="card-body">

            </div>
        </div>
    </div>
</body>

</html>