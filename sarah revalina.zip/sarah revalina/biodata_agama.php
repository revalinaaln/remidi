<?php
$host    = "localhost";
$user    = "root";
$pass    = "";
$db      = "biodata_reva";

$koneksi = mysqli_connect($host, $user, $pass, $db);
if(!$koneksi){ //cek koneksi
   die("Tidak bisa terkoneksi ke database");
}
$id         = "";
$nama_agama = "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>biodata_agama.php</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        .max-auto { width:800px}
        .card { margin-top: 20px;}
    </style>
</head>

<body>
    <div class="max-auto">
        <!-- untuk memasukkan data -->
    <div class="card">
  <div class="card-header">
    Create / Edit data
  </div>
  <div class="card-body">
    <form action="" method="POST">
    <div class="mb-3 row">
    <label for="id" class="col-sm-2 col-form-label">ID</label>
    <div class="col-sm-10">
      <input type="text" class="form-control-plaintext" id="id" value="<?php echo $id?>">
    </div>
  </div>
  <div class="mb-3 row">
    <label for="nama_agama" class="col-sm-2 col-form-label">NAMA_AGAMA</label>
    <div class="col-sm-10">
      <input type="text" class="form-control-plaintext" id="nama_agama" value="<?php echo $nama_agama?>">
    </div>
  </div>
    <input type="submit" name"simpan" values="Simpan Data" class="btn btn-primary"/>
  </div>
    </form>
  </div>
</div>

<!-- untuk mengeluarkan data -->
<div class="card">
  <div class="card-header text-white bg-secondary">
    biodata_agama.php
  </div>
  <div class="card-body">
    
  </div>
</div>
    </div>
</body>
</html>